import { useEffect, useRef, useState } from 'react';

export default function App() {
  return (
    <div className="min-h-screen" style={{ 
      fontFamily: "'Outfit', sans-serif",
      background: '#0a0e1a',
      color: '#e8f4fd',
      backgroundImage: `repeating-linear-gradient(0deg, rgba(30, 58, 95, 0.15) 0px, rgba(30, 58, 95, 0.15) 1px, transparent 1px, transparent 40px),
                        repeating-linear-gradient(90deg, rgba(30, 58, 95, 0.15) 0px, rgba(30, 58, 95, 0.15) 1px, transparent 1px, transparent 40px)`
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=JetBrains+Mono:wght@400;500;600;700&family=Outfit:wght@300;400;500;600;700&display=swap');
        
        :root {
          --bg-primary: #0a0e1a;
          --bg-panel: #0f1629;
          --bg-panel-alt: #141d35;
          --border-glow: #1e3a5f;
          --accent-green: #00e676;
          --accent-yellow: #ffca28;
          --accent-red: #ff1744;
          --accent-blue: #29b6f6;
          --accent-orange: #ff6d00;
          --text-primary: #e8f4fd;
          --text-secondary: #7a9bbf;
          --text-muted: #3a5a7a;
        }
        
        ::-webkit-scrollbar {
          width: 6px;
        }
        
        ::-webkit-scrollbar-track {
          background: var(--bg-primary);
        }
        
        ::-webkit-scrollbar-thumb {
          background: var(--border-glow);
          border-radius: 3px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: var(--accent-blue);
        }
        
        @keyframes dataFlash {
          0% { opacity: 0.5; }
          50% { opacity: 1; color: var(--accent-blue); text-shadow: 0 0 8px var(--accent-blue); }
          100% { opacity: 1; }
        }
        
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.6; transform: scale(0.9); }
        }
        
        @keyframes slideInRight {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOutRight {
          from { transform: translateX(0); opacity: 1; }
          to { transform: translateX(100%); opacity: 0; }
        }
        
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes barAnimation {
          0%, 100% { height: 40%; }
          50% { height: 100%; }
        }
        
        .flash-value {
          animation: dataFlash 0.6s ease-out;
        }
        
        .pulse-dot {
          animation: pulse 2s infinite;
        }
        
        .slide-in {
          animation: slideInRight 0.3s ease-out;
        }
        
        .slide-out {
          animation: slideOutRight 0.3s ease-out forwards;
        }
        
        .fade-in {
          animation: fadeIn 0.5s ease-out;
        }
        
        .bar-animate-1 {
          animation: barAnimation 1.2s ease-in-out infinite;
        }
        
        .bar-animate-2 {
          animation: barAnimation 1.2s ease-in-out 0.2s infinite;
        }
        
        .bar-animate-3 {
          animation: barAnimation 1.2s ease-in-out 0.4s infinite;
        }
      `}</style>
      
      <SmartWattDashboard />
    </div>
  );
}

function SmartWattDashboard() {
  const [state, setState] = useState({
    relayOn: true,
    switchOn: true,
    autoCutoff: true,
    voltage: 230,
    current: 1.07,
    power: 247,
    totalKwh: 1.082,
    totalCost: 3.42,
    tariffRate: 7.20,
    dailyBudget: 5.00,
    maxPower: 300,
    maxRuntime: 6,
    restrictedStart: "23:00",
    restrictedEnd: "05:00",
    standbyThreshold: 0.10,
    runtimeSeconds: 15720,
    alertCount: 3,
    rules: {
      oddHour: false,
      powerSpike: false,
      runtimeLimit: false,
      budgetWarning: false,
      budgetCritical: false,
      fault: false,
      vampire: false
    }
  });
  
  const [currentTime, setCurrentTime] = useState(new Date());
  const [alerts, setAlerts] = useState<any[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [chartData, setChartData] = useState<number[]>([]);
  const [updateTrigger, setUpdateTrigger] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);
  
  // Initialize chart data
  useEffect(() => {
    const initialData = Array(30).fill(0).map(() => 247 + (Math.random() - 0.5) * 30);
    setChartData(initialData);
  }, []);
  
  // Load Chart.js
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
    script.async = true;
    script.onload = () => {
      if (canvasRef.current && window.Chart) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          chartRef.current = new (window as any).Chart(ctx, {
            type: 'line',
            data: {
              labels: Array(30).fill(0).map((_, i) => {
                const time = new Date();
                time.setSeconds(time.getSeconds() - (30 - i) * 1.5);
                return time.toTimeString().slice(0, 8);
              }),
              datasets: [{
                label: 'Power (W)',
                data: chartData,
                borderColor: '#29b6f6',
                backgroundColor: function(context: any) {
                  const chart = context.chart;
                  const {ctx, chartArea} = chart;
                  if (!chartArea) return null;
                  const gradient = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
                  gradient.addColorStop(0, 'rgba(41, 182, 246, 0.3)');
                  gradient.addColorStop(1, 'rgba(41, 182, 246, 0)');
                  return gradient;
                },
                fill: true,
                pointRadius: 2,
                pointHoverRadius: 5,
                tension: 0.4
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              animation: { duration: 300 },
              plugins: {
                legend: { display: false },
                tooltip: {
                  backgroundColor: '#0f1629',
                  borderColor: '#1e3a5f',
                  borderWidth: 1
                }
              },
              scales: {
                x: {
                  ticks: { color: '#7a9bbf', font: { family: 'JetBrains Mono', size: 10 } },
                  grid: { color: 'rgba(30, 58, 95, 0.4)' }
                },
                y: {
                  min: 0,
                  max: 350,
                  ticks: { color: '#7a9bbf', font: { family: 'JetBrains Mono', size: 10 } },
                  grid: { color: 'rgba(30, 58, 95, 0.4)' }
                }
              }
            }
          });
        }
      }
    };
    document.body.appendChild(script);
    
    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, []);
  
  // Update chart
  useEffect(() => {
    if (chartRef.current && chartData.length > 0) {
      chartRef.current.data.datasets[0].data = chartData;
      const time = new Date();
      chartRef.current.data.labels.push(time.toTimeString().slice(0, 8));
      if (chartRef.current.data.labels.length > 30) {
        chartRef.current.data.labels.shift();
      }
      chartRef.current.update();
    }
  }, [chartData]);
  
  // Clock update
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  
  // Simulation tick
  useEffect(() => {
    const interval = setInterval(() => {
      setState(prev => {
        const time = Date.now() / 1000;
        const voltageNoise = Math.sin(time * 0.1) * 3 + (Math.random() - 0.5) * 2;
        let newVoltage = 230 + voltageNoise;
        let newCurrent = prev.current;
        
        if (prev.relayOn) {
          if (prev.switchOn) {
            const currentNoise = Math.sin(time * 0.15) * 0.1 + (Math.random() - 0.5) * 0.05;
            newCurrent = 1.07 + currentNoise;
          } else {
            newCurrent = 0.18; // Vampire load
          }
        } else {
          newCurrent = 0;
        }
        
        const newPower = newVoltage * newCurrent;
        const deltaSeconds = 1.5;
        const newTotalKwh = prev.totalKwh + (newPower / 1000) * (deltaSeconds / 3600);
        const newTotalCost = newTotalKwh * prev.tariffRate;
        
        // Update chart
        setChartData(prevData => {
          const newData = [...prevData, newPower];
          return newData.slice(-30);
        });
        
        return {
          ...prev,
          voltage: newVoltage,
          current: newCurrent,
          power: newPower,
          totalKwh: newTotalKwh,
          totalCost: newTotalCost
        };
      });
      
      setUpdateTrigger(prev => prev + 1);
    }, 1500);
    
    return () => clearInterval(interval);
  }, []);
  
  // Runtime counter
  useEffect(() => {
    const interval = setInterval(() => {
      if (state.relayOn && state.switchOn) {
        setState(prev => ({ ...prev, runtimeSeconds: prev.runtimeSeconds + 1 }));
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [state.relayOn, state.switchOn]);
  
  // Initialize alerts
  useEffect(() => {
    setAlerts([
      { id: 1, severity: 'info', title: 'System initialized. Motor — Load 1 connected. Monitoring active.', body: 'ESP32 Node DEV-001 connected successfully. Real-time monitoring started.', rule: 'System', time: '09:00:01' },
      { id: 2, severity: 'info', title: 'Tariff applied: Delhi slab ₹7.20/unit. Cost computation active.', body: 'Electricity tariff configured for Delhi region. Cost calculations are now live.', rule: 'Config', time: '09:00:05' },
      { id: 3, severity: 'warning', title: 'Daily budget at 68%. Approaching ₹4.00 warning threshold.', body: 'Current spending: ₹3.42 of ₹5.00 daily budget. Warning will trigger at 80%.', rule: 'Rule: Budget', time: '13:45:22' }
    ]);
  }, []);
  
  const formatTime = (date: Date) => date.toTimeString().slice(0, 8);
  
  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };
  
  const budgetPercent = (state.totalCost / state.dailyBudget) * 100;
  const systemStatus = state.rules.powerSpike || state.rules.budgetCritical || state.rules.fault ? 'critical' : 
                       state.rules.oddHour || state.rules.runtimeLimit || state.rules.budgetWarning || state.rules.vampire ? 'warning' : 'normal';
  
  const days = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const timeStr = `${days[currentTime.getDay()]}, ${currentTime.getDate()} ${months[currentTime.getMonth()]} ${currentTime.getFullYear()}  ${formatTime(currentTime)}`;
  
  return (
    <>
      {/* Navbar */}
      <nav style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        height: '56px',
        background: 'rgba(10, 14, 26, 0.95)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid #1e3a5f',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'center',
        padding: '0 24px'
      }}>
        <div style={{ maxWidth: '1400px', width: '100%', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ fontFamily: 'Orbitron, sans-serif', fontSize: '18px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ color: '#00e676' }}>⚡</span>
              <span style={{ color: '#e8f4fd' }}>Smart</span>
              <span style={{ color: '#29b6f6' }}>Watt</span>
            </div>
            <div style={{ fontSize: '8px', background: 'rgba(41, 182, 246, 0.15)', border: '1px solid #29b6f6', borderRadius: '4px', color: '#29b6f6', padding: '2px 6px' }}>
              PROTOTYPE v1.0
            </div>
          </div>
          <div style={{ fontFamily: 'JetBrains Mono, monospace', color: '#7a9bbf', fontSize: '13px', letterSpacing: '1px' }}>
            {timeStr}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', fontSize: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#00e676' }}>
              <div className="pulse-dot" style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#00e676', boxShadow: '0 0 8px #00e676' }}></div>
              <span>LIVE</span>
            </div>
            <span style={{ color: '#3a5a7a' }}>|</span>
            <span style={{ color: '#7a9bbf' }}>1 Device Connected</span>
            <span style={{ color: '#3a5a7a' }}>|</span>
            <button style={{ position: 'relative', background: 'none', border: 'none', fontSize: '16px', cursor: 'pointer', padding: '4px' }}>
              🔔
              <div className="pulse-dot" style={{ position: 'absolute', top: '-2px', right: '-2px', width: '16px', height: '16px', borderRadius: '50%', background: '#ff1744', color: 'white', fontSize: '9px', fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {state.alertCount}
              </div>
            </button>
          </div>
        </div>
      </nav>
      
      <div style={{ maxWidth: '1400px', margin: '0 auto', padding: '0 24px' }}>
        {/* Hero Status Bar */}
        <section className="fade-in" style={{
          marginTop: '72px',
          background: 'linear-gradient(135deg, #0f1629 0%, #111e38 100%)',
          border: '1px solid #1e3a5f',
          borderRadius: '12px',
          padding: '20px 28px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '24px',
          boxShadow: '0 0 20px rgba(0, 150, 255, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.03)'
        }}>
          <div>
            <div style={{ fontFamily: 'Outfit, sans-serif', fontSize: '11px', color: '#3a5a7a', letterSpacing: '2px', textTransform: 'uppercase' }}>
              SYSTEM STATUS
            </div>
            <div style={{
              fontFamily: 'Orbitron, sans-serif',
              fontSize: '20px',
              fontWeight: 700,
              color: systemStatus === 'critical' ? '#ff1744' : systemStatus === 'warning' ? '#ffca28' : '#00e676',
              textShadow: systemStatus === 'critical' ? '0 0 24px rgba(255, 23, 68, 0.3)' : systemStatus === 'warning' ? '0 0 24px rgba(255, 202, 40, 0.3)' : '0 0 24px rgba(0, 230, 118, 0.3)'
            }}>
              {systemStatus === 'critical' ? 'CRITICAL ALERT' : systemStatus === 'warning' ? 'WARNING DETECTED' : 'ALL SYSTEMS NORMAL'}
            </div>
          </div>
          
          <div style={{ display: 'flex', gap: '20px' }}>
            <StatChip label="TOTAL POWER" value={`${Math.round(state.power)} W`} color="#29b6f6" />
            <StatChip label="TODAY'S COST" value={`₹ ${state.totalCost.toFixed(2)}`} color="#00e676" />
            <StatChip label="RUNTIME TODAY" value={formatDuration(state.runtimeSeconds)} color="#e8f4fd" />
          </div>
          
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            padding: '10px 20px',
            borderRadius: '20px',
            background: state.relayOn ? 'rgba(0, 230, 118, 0.15)' : 'rgba(255, 23, 68, 0.15)',
            border: state.relayOn ? '1px solid #00e676' : '1px solid #ff1744',
            color: state.relayOn ? '#00e676' : '#ff1744'
          }}>
            <span style={{ fontSize: '12px' }}>⬤</span>
            <span style={{ fontFamily: 'Outfit, sans-serif', fontSize: '12px', fontWeight: 600, letterSpacing: '1px' }}>
              {state.relayOn ? 'RELAY ON — APPLIANCE ACTIVE' : 'RELAY OFF — APPLIANCE INACTIVE'}
            </span>
          </div>
        </section>
        
        {/* Main Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 0.65fr', gap: '20px', marginTop: '20px' }}>
          {/* Device Card */}
          <Panel>
            <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start', position: 'relative', marginBottom: '16px' }}>
              <div style={{
                width: '56px',
                height: '56px',
                background: 'rgba(41, 182, 246, 0.1)',
                border: '1px solid rgba(41, 182, 246, 0.3)',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '28px'
              }}>⚡</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'Orbitron, sans-serif', fontSize: '18px', marginBottom: '4px' }}>Motor — Load 1</div>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '11px', color: '#3a5a7a', marginBottom: '4px' }}>
                  DEV-001 | ESP32 Node
                </div>
                <div style={{ fontSize: '11px', color: '#3a5a7a' }}>Updated 1.2s ago</div>
              </div>
              <div style={{
                padding: '6px 16px',
                borderRadius: '20px',
                fontFamily: 'Orbitron, sans-serif',
                fontSize: '11px',
                fontWeight: 700,
                letterSpacing: '1px',
                background: systemStatus === 'critical' ? 'rgba(255, 23, 68, 0.15)' : systemStatus === 'warning' ? 'rgba(255, 202, 40, 0.15)' : 'rgba(0, 230, 118, 0.15)',
                border: systemStatus === 'critical' ? '1px solid #ff1744' : systemStatus === 'warning' ? '1px solid #ffca28' : '1px solid #00e676',
                color: systemStatus === 'critical' ? '#ff1744' : systemStatus === 'warning' ? '#ffca28' : '#00e676',
                boxShadow: systemStatus === 'critical' ? '0 0 24px rgba(255, 23, 68, 0.3)' : systemStatus === 'warning' ? '0 0 24px rgba(255, 202, 40, 0.3)' : '0 0 24px rgba(0, 230, 118, 0.3)'
              }}>
                {systemStatus === 'critical' ? '✖ CRITICAL' : systemStatus === 'warning' ? '▲ WARNING' : '● NORMAL'}
              </div>
            </div>
            
            <Divider />
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px', marginBottom: '16px' }}>
              <ReadingBox label="VOLTAGE" value={`${state.voltage.toFixed(1)} V`} micro="Nominal: 220–240 V" color="#29b6f6" flash={updateTrigger} />
              <ReadingBox label="CURRENT" value={`${state.current.toFixed(2)} A`} micro="Threshold: 2.0 A max" color="#00e676" flash={updateTrigger} />
              <ReadingBox label="REAL POWER" value={`${Math.round(state.power)} W`} micro="P = V × I (computed)" color="#ffca28" flash={updateTrigger} />
              <ReadingBox label="ENERGY TODAY" value={`${state.totalKwh.toFixed(3)} kWh`} micro="Session start: 09:00 AM" color="#7a9bbf" flash={updateTrigger} />
            </div>
          </Panel>
          
          {/* Control Panel */}
          <Panel>
            <PanelHeader>CONTROL PANEL</PanelHeader>
            <div style={{ fontSize: '12px', color: '#3a5a7a', marginBottom: '20px' }}>Manual override & enforcement settings</div>
            
            <ControlSection
              label="RELAY POWER"
              active={state.relayOn}
              onToggle={() => setState(prev => ({ ...prev, relayOn: !prev.relayOn }))}
              statusText={state.relayOn ? 'Appliance is currently ENERGIZED' : 'Appliance is currently DE-ENERGIZED'}
              statusColor={state.relayOn ? '#00e676' : '#ff1744'}
              warning="⚠ Auto-cutoff will override manual control when limits are breached."
            />
            
            <ControlSection
              label="AUTO ENFORCEMENT"
              active={state.autoCutoff}
              onToggle={() => setState(prev => ({ ...prev, autoCutoff: !prev.autoCutoff }))}
              statusText={state.autoCutoff ? 'ENABLED' : 'DISABLED'}
              statusColor={state.autoCutoff ? '#00e676' : '#ff1744'}
              subtitle="Automatically cut relay when limits are exceeded"
              small
            />
            
            <Divider />
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '10px', marginBottom: '16px' }}>
              <QuickStat label="Switch State" value={state.switchOn ? 'ON' : 'OFF'} />
              <QuickStat label="Relay State" value={state.relayOn ? 'ON' : 'OFF'} />
              <QuickStat label="Auto-Cutoff" value={state.autoCutoff ? 'ON' : 'OFF'} />
              <QuickStat label="Session Duration" value={formatDuration(state.runtimeSeconds)} />
            </div>
            
            <Divider />
            
            <ActionButton color="warning" onClick={() => {
              const newAlert = { 
                id: Date.now(), 
                severity: 'info', 
                title: 'Test Alert Triggered', 
                body: 'This is a manual test alert triggered from the control panel.', 
                rule: 'Manual Test', 
                time: formatTime(new Date()) 
              };
              setAlerts(prev => [newAlert, ...prev]);
              setState(prev => ({ ...prev, alertCount: prev.alertCount + 1 }));
            }}>
              ⚡ Trigger Test Alert
            </ActionButton>
            
            <ActionButton color="danger" onClick={() => {
              setState(prev => ({ ...prev, rules: { ...prev.rules, fault: true } }));
              const newAlert = { 
                id: Date.now(), 
                severity: 'critical', 
                title: 'Fault Detected (Simulated)', 
                body: 'Simulation: Device is switched ON but current reading is near zero.', 
                rule: 'Rule: Fault Detection', 
                time: formatTime(new Date()) 
              };
              setAlerts(prev => [newAlert, ...prev]);
              setState(prev => ({ ...prev, alertCount: prev.alertCount + 1 }));
            }} style={{ marginTop: '8px' }}>
              🔴 Simulate Fault Detection
            </ActionButton>
            
            <ActionButton color="orange" onClick={() => {
              setState(prev => ({ ...prev, switchOn: false, current: 0.18, rules: { ...prev.rules, vampire: true } }));
              const newAlert = { 
                id: Date.now(), 
                severity: 'vampire', 
                title: 'Vampire Load Detected (Simulated)', 
                body: 'Device switch is OFF but standby current of 0.18A detected.', 
                rule: 'Rule: Vampire Load', 
                time: formatTime(new Date()) 
              };
              setAlerts(prev => [newAlert, ...prev]);
              setState(prev => ({ ...prev, alertCount: prev.alertCount + 1 }));
            }} style={{ marginTop: '8px' }}>
              🩸 Simulate Vampire Load
            </ActionButton>
          </Panel>
        </div>
        
        {/* Live Metrics Strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginTop: '20px' }}>
          <MetricBox icon="₹" label="COST / HOUR" value={`₹ ${((state.power / 1000) * state.tariffRate).toFixed(2)}`} sub="@ ₹7.20 per unit (Delhi tariff)" />
          
          <Panel style={{ textAlign: 'center', padding: '20px' }}>
            <div style={{ fontSize: '11px', color: '#3a5a7a', letterSpacing: '1.5px', textTransform: 'uppercase', marginBottom: '8px' }}>
              BUDGET USED
            </div>
            <svg width="120" height="120" viewBox="0 0 120 120" style={{ margin: '0 auto 12px' }}>
              <circle cx="60" cy="60" r="54" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8"/>
              <circle 
                cx="60" 
                cy="60" 
                r="54" 
                fill="none" 
                stroke="#00e676" 
                strokeWidth="8"
                strokeDasharray="339.292"
                strokeDashoffset={339.292 - (budgetPercent / 100) * 339.292}
                transform="rotate(-90 60 60)"
                strokeLinecap="round"
              />
              <text x="60" y="68" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="20" fill="#e8f4fd">
                {Math.round(budgetPercent)}%
              </text>
            </svg>
            <div style={{ fontSize: '10px', color: '#3a5a7a' }}>₹ {state.totalCost.toFixed(2)} of ₹{state.dailyBudget.toFixed(2)} budget</div>
          </Panel>
          
          <MetricBox label="POWER FACTOR" value="0.97" sub="Estimated — sensor limitation" color="#29b6f6" />
          
          <Panel style={{ textAlign: 'center', padding: '20px' }}>
            <div style={{ display: 'flex', gap: '4px', justifyContent: 'center', height: '24px', alignItems: 'flex-end', marginBottom: '12px' }}>
              <div className="bar-animate-1" style={{ width: '6px', background: '#29b6f6', borderRadius: '3px 3px 0 0', height: '60%' }}></div>
              <div className="bar-animate-2" style={{ width: '6px', background: '#29b6f6', borderRadius: '3px 3px 0 0', height: '40%' }}></div>
              <div className="bar-animate-3" style={{ width: '6px', background: '#29b6f6', borderRadius: '3px 3px 0 0', height: '80%' }}></div>
            </div>
            <div style={{ fontSize: '11px', color: '#3a5a7a', letterSpacing: '1.5px', textTransform: 'uppercase', marginBottom: '8px' }}>
              DATA REFRESH
            </div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '26px', fontWeight: 600, marginBottom: '6px' }}>
              1.2 s
            </div>
            <div style={{ fontSize: '10px', color: '#3a5a7a' }}>ESP32 ADC @ ~1–2s intervals</div>
          </Panel>
        </div>
        
        {/* Energy & Cost Section */}
        <div style={{ display: 'grid', gridTemplateColumns: '0.55fr 1fr', gap: '20px', marginTop: '20px' }}>
          <Panel>
            <PanelHeader>COST BREAKDOWN</PanelHeader>
            
            <div style={{
              padding: '8px 12px',
              background: 'rgba(41, 182, 246, 0.08)',
              border: '1px solid rgba(41, 182, 246, 0.2)',
              borderRadius: '6px',
              fontSize: '12px',
              color: '#7a9bbf',
              marginBottom: '16px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}>
              <span>ⓘ</span>
              <span>Delhi Tariff Active: ₹7.20/unit (≤200 kWh slab)</span>
            </div>
            
            <CostRow label="This Hour" value={`₹ ${((state.power / 1000) * state.tariffRate).toFixed(2)}`} color="#00e676" />
            <CostRow label="Today (so far)" value={`₹ ${state.totalCost.toFixed(2)}`} color="#00e676" />
            <CostRow label="Projected Today" value={`₹ ${(state.totalCost * 1.2).toFixed(2)}`} color="#7a9bbf" />
            <CostRow label="Projected Monthly" value={`₹ ${(state.totalCost * 30).toFixed(2)}`} color="#7a9bbf" />
            <CostRow label="Standby Waste Today" value="₹ 0.14" color="#ff6d00" noBorder />
            
            <div style={{
              background: 'rgba(0, 230, 118, 0.06)',
              borderRadius: '8px',
              padding: '12px',
              marginTop: '16px'
            }}>
              <div style={{ fontSize: '11px', color: '#3a5a7a', letterSpacing: '2px', textTransform: 'uppercase', marginBottom: '8px' }}>
                DAILY BUDGET STATUS
              </div>
              <div style={{ width: '100%', height: '8px', background: 'rgba(255, 255, 255, 0.06)', borderRadius: '4px', margin: '12px 0', overflow: 'hidden' }}>
                <div style={{ height: '100%', background: '#00e676', borderRadius: '4px', width: `${budgetPercent}%`, transition: 'width 1s ease' }}></div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#3a5a7a', marginBottom: '8px' }}>
                <span>₹ {state.totalCost.toFixed(2)} spent of ₹ {state.dailyBudget.toFixed(2)} limit</span>
                <span>{Math.round(100 - budgetPercent)}% remaining</span>
              </div>
              <div style={{ fontSize: '10px', color: '#ffca28' }}>⚠ Warning triggers at ₹ 4.00 (80%)</div>
            </div>
          </Panel>
          
          <Panel>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <PanelHeader>REAL-TIME POWER CONSUMPTION</PanelHeader>
            </div>
            <div style={{ height: '220px' }}>
              <canvas ref={canvasRef} style={{ width: '100%', height: '100%' }}></canvas>
            </div>
            <div style={{
              display: 'flex',
              justifyContent: 'space-around',
              marginTop: '12px',
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: '12px',
              color: '#3a5a7a'
            }}>
              <span>MIN: {Math.round(Math.min(...chartData))} W</span>
              <span>|</span>
              <span>MAX: {Math.round(Math.max(...chartData))} W</span>
              <span>|</span>
              <span>AVG: {Math.round(chartData.reduce((a, b) => a + b, 0) / chartData.length)} W</span>
              <span>|</span>
              <span>TREND: ↑ +2.1 W</span>
            </div>
          </Panel>
        </div>
        
        {/* Footer */}
        <div style={{
          borderTop: '1px solid #1e3a5f',
          padding: '16px 0',
          margin: '40px 0 20px',
          textAlign: 'center',
          fontSize: '11px',
          color: '#3a5a7a'
        }}>
          SmartWatt v1.0 | GGSIPU B.Tech IIoT | HackNova 3.0 | Prototype — Not for industrial use
        </div>
      </div>
    </>
  );
}

// Helper Components
function Panel({ children, style = {} }: any) {
  return (
    <div className="fade-in" style={{
      background: '#0f1629',
      border: '1px solid #1e3a5f',
      borderRadius: '12px',
      padding: '24px',
      boxShadow: '0 0 20px rgba(0, 150, 255, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.03)',
      ...style
    }}>
      {children}
    </div>
  );
}

function PanelHeader({ children }: any) {
  return (
    <div style={{
      fontFamily: 'Orbitron, sans-serif',
      fontSize: '14px',
      color: '#29b6f6',
      letterSpacing: '2px',
      textTransform: 'uppercase',
      marginBottom: '8px'
    }}>
      {children}
    </div>
  );
}

function Divider() {
  return <div style={{ height: '1px', background: '#1e3a5f', margin: '16px 0' }}></div>;
}

function StatChip({ label, value, color }: any) {
  return (
    <div style={{
      background: '#141d35',
      border: '1px solid #1e3a5f',
      borderRadius: '8px',
      padding: '8px 20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '4px'
    }}>
      <div style={{ fontSize: '10px', color: '#3a5a7a', letterSpacing: '1.5px', textTransform: 'uppercase' }}>
        {label}
      </div>
      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '22px', fontWeight: 600, color }}>
        {value}
      </div>
    </div>
  );
}

function ReadingBox({ label, value, micro, color, flash }: any) {
  return (
    <div style={{
      background: '#141d35',
      borderRadius: '8px',
      padding: '14px 16px',
      borderLeft: `3px solid ${color}`
    }}>
      <div style={{ fontSize: '10px', color: '#3a5a7a', letterSpacing: '1.5px', textTransform: 'uppercase', marginBottom: '6px' }}>
        {label}
      </div>
      <div key={flash} className="flash-value" style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '28px', fontWeight: 600, marginBottom: '4px', color }}>
        {value}
      </div>
      <div style={{ fontSize: '10px', color: '#3a5a7a' }}>{micro}</div>
    </div>
  );
}

function ControlSection({ label, active, onToggle, statusText, statusColor, warning, subtitle, small }: any) {
  return (
    <div style={{
      background: '#141d35',
      borderRadius: '10px',
      padding: '16px',
      marginBottom: '16px'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
        <span style={{ fontSize: '13px', fontWeight: 500 }}>{label}</span>
        <div
          onClick={onToggle}
          style={{
            position: 'relative',
            width: small ? '48px' : '60px',
            height: small ? '24px' : '30px',
            background: active ? '#00e676' : '#1a2a3a',
            borderRadius: small ? '12px' : '15px',
            cursor: 'pointer',
            transition: 'all 0.3s ease',
            boxShadow: active ? '0 0 12px #00e676' : 'none'
          }}
        >
          <div style={{
            position: 'absolute',
            top: '3px',
            left: '3px',
            width: small ? '18px' : '24px',
            height: small ? '18px' : '24px',
            background: 'white',
            borderRadius: '50%',
            transition: 'all 0.3s ease',
            transform: active ? `translateX(${small ? '24px' : '30px'})` : 'translateX(0)'
          }}></div>
        </div>
      </div>
      {subtitle && <div style={{ fontSize: '12px', color: '#3a5a7a', marginBottom: '8px' }}>{subtitle}</div>}
      <div style={{ fontSize: '12px', marginTop: '8px', color: statusColor }}>
        {statusText}
      </div>
      {warning && <div style={{ fontSize: '11px', color: '#3a5a7a', fontStyle: 'italic', marginTop: '8px' }}>{warning}</div>}
    </div>
  );
}

function QuickStat({ label, value }: any) {
  return (
    <div style={{ background: '#141d35', padding: '10px', borderRadius: '6px' }}>
      <div style={{ fontSize: '10px', color: '#3a5a7a', marginBottom: '4px' }}>{label}</div>
      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '14px' }}>{value}</div>
    </div>
  );
}

function ActionButton({ children, color, onClick, style = {} }: any) {
  const colors = {
    warning: { border: '#ffca28', bg: 'rgba(255, 202, 40, 0.08)', text: '#ffca28' },
    danger: { border: '#ff1744', bg: 'rgba(255, 23, 68, 0.08)', text: '#ff1744' },
    orange: { border: '#ff6d00', bg: 'rgba(255, 109, 0, 0.08)', text: '#ff6d00' }
  };
  
  const c = colors[color as keyof typeof colors];
  
  return (
    <button
      onClick={onClick}
      style={{
        width: '100%',
        height: '40px',
        borderRadius: '8px',
        fontSize: '13px',
        cursor: 'pointer',
        transition: 'all 0.2s ease',
        background: c.bg,
        border: `1px solid ${c.border}`,
        color: c.text,
        ...style
      }}
    >
      {children}
    </button>
  );
}

function MetricBox({ icon, label, value, sub, color = '#00e676' }: any) {
  return (
    <Panel style={{ textAlign: 'center', padding: '20px' }}>
      {icon && <div style={{ fontSize: '32px', color, marginBottom: '12px' }}>{icon}</div>}
      <div style={{ fontSize: '11px', color: '#3a5a7a', letterSpacing: '1.5px', textTransform: 'uppercase', marginBottom: '8px' }}>
        {label}
      </div>
      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '26px', fontWeight: 600, color, marginBottom: '6px' }}>
        {value}
      </div>
      <div style={{ fontSize: '10px', color: '#3a5a7a' }}>{sub}</div>
    </Panel>
  );
}

function CostRow({ label, value, color, noBorder }: any) {
  return (
    <div style={{
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '12px 0',
      borderBottom: noBorder ? 'none' : '1px solid rgba(30, 58, 95, 0.5)'
    }}>
      <span style={{ fontSize: '13px', color: '#7a9bbf' }}>{label}</span>
      <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '18px', color }}>{value}</span>
    </div>
  );
}

declare global {
  interface Window {
    Chart: any;
  }
}


  # SmartWatt Dashboard Prototype

  This is a code bundle for SmartWatt Dashboard Prototype. The original project is available at https://www.figma.com/design/rhqdjhySvOK5fI1nwLL6fj/SmartWatt-Dashboard-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  